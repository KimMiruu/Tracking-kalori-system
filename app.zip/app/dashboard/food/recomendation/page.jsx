// app/page.jsx
'use client'

import { useEffect, useState } from 'react'

/* Improved UI + very tidy Recipe modal (better typography, spacing, macros) */

/* constants */
const COOKED_JSON_URL = '/api/cooked-foods'

/* helpers */
function normalizeCookedArray(data) {
  if (!Array.isArray(data)) return []
  return data.map((it, idx) => {
    const id = it.id ?? it.label ?? `cooked-${idx}`
    return {
      id,
      name: it.nama_makanan ?? it.name ?? it.nama ?? it.title ?? `Makanan ${idx + 1}`,
      kalori: Number(it.kalori ?? it.kcal ?? it.calories ?? 0),
      protein: Number(it.protein ?? it.protein_g ?? it.protein_gram ?? 0),
      carbs: Number(it.carbs ?? it.carbohydrate ?? it.carbohidrat ?? 0),
      fat: Number(it.fat ?? it.lemak ?? 0),
      tags: it.tags ?? it.kategori ?? [],
      recipe: it.recipe ?? it.resep ?? null
    }
  })
}

function pickFoods(arr, targetKcal, maxItems = 3) {
  if (!Array.isArray(arr) || arr.length === 0) return []
  const sorted = arr.slice().sort((a, b) => Math.abs(targetKcal - a.kalori) - Math.abs(targetKcal - b.kalori))
  return sorted.slice(0, maxItems)
}

function generateDailyPlan(sisaKalori, cookedArr) {
  const targetSarapan = Math.round(sisaKalori * 0.25)
  const targetSiang = Math.round(sisaKalori * 0.35)
  const targetMalam = Math.round(sisaKalori * 0.30)
  const targetCamilan = Math.round(sisaKalori * 0.10)

  const byTag = {}
  cookedArr.forEach((it) => {
    if (!Array.isArray(it.tags) || it.tags.length === 0) {
      const tag = 'lainnya'
      byTag[tag] = byTag[tag] || []
      byTag[tag].push(it)
    } else {
      it.tags.forEach((tag) => {
        byTag[tag] = byTag[tag] || []
        byTag[tag].push(it)
      })
    }
  })

  function getGroup(meal) {
    if (meal === 'sarapan') return byTag['sarapan'] || byTag['breakfast'] || cookedArr
    if (meal === 'makan_siang') return byTag['siang'] || byTag['lunch'] || cookedArr
    if (meal === 'makan_malam') return byTag['malam'] || byTag['dinner'] || cookedArr
    if (meal === 'camilan') return byTag['camilan'] || byTag['snack'] || cookedArr
    return cookedArr
  }

  const byMeal = {}
  byMeal.sarapan = pickFoods(getGroup('sarapan'), targetSarapan)
  byMeal.makan_siang = pickFoods(getGroup('makan_siang'), targetSiang)
  byMeal.makan_malam = pickFoods(getGroup('makan_malam'), targetMalam)
  byMeal.camilan = pickFoods(getGroup('camilan'), targetCamilan)

  return {
    byMeal,
    targets: { targetSarapan, targetSiang, targetMalam, targetCamilan }
  }
}

function fmt(n) {
  if (typeof n !== 'number') return n
  return n.toLocaleString('id-ID')
}

/* style tokens */
const brand = {
  purple: '#7c3aed',
  teal: '#06b6d4',
  orange: '#fb923c',
  green: '#10b981',
  red: '#ef4444',
  muted: '#64748b',
  bg: '#fbfdff'
}

const C = {
  page: { maxWidth: 1150, margin: '0 auto', padding: '120px 18px 80px', background: brand.bg },
  hero: {
    borderRadius: 14,
    padding: 14,
    background: `linear-gradient(90deg, ${brand.purple}, ${brand.teal})`,
    color: '#fff',
    boxShadow: '0 10px 30px rgba(2,6,23,0.12)'
  },
  heroRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, flexWrap: 'wrap' },
  heroText: { fontSize: 18, fontWeight: 700, margin: 0 },
  heroSub: { fontSize: 13, marginTop: 6, opacity: 0.95 },
  statsGrid: { display: 'grid', gap: 12, gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', marginTop: 12 },
  statCard: { background: '#fff', padding: 14, borderRadius: 10, boxShadow: '0 8px 24px rgba(2,6,23,0.04)', minHeight: 84, color: '#0f172a' },
  statLabel: { fontSize: 12, color: brand.muted },
  statValue: { fontSize: 20, fontWeight: 800, marginTop: 8, color: '#0f172a' },
  meals: { marginTop: 18 },
  sectionHead: { display: 'flex', alignItems: 'center', gap: 10, marginTop: 18, marginBottom: 8 },
  sectionH2: { fontSize: 16, fontWeight: 800, margin: 0 },
  mealCard: { background: '#fff', borderRadius: 12, padding: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, boxShadow: '0 8px 30px rgba(2,6,23,0.04)', marginBottom: 12, borderLeft: '6px solid #fff' },
  left: { display: 'flex', gap: 12, alignItems: 'center' },
  name: { fontWeight: 800, fontSize: 15, color: '#0f172a' },
  meta: { color: brand.muted, fontSize: 13 },
  right: { textAlign: 'right', minWidth: 120, color: brand.muted },
  badge: { display: 'inline-block', padding: '6px 10px', borderRadius: 999, background: '#fff', boxShadow: '0 2px 6px rgba(2,6,23,0.04)', fontSize: 12 }
}

const accent = {
  sarapan: brand.green,
  makan_siang: brand.orange,
  makan_malam: brand.purple,
  camilan: brand.red
}

const Skeleton = ({ width = '70%' }) => <div style={{ height: 12, width, background: '#eef2ff', borderRadius: 6 }} />

/* Main component */
export default function FoodRecommendationPage() {
  const [sisaKalori, setSisaKalori] = useState(null)
  const [kaloriSummary, setKaloriSummary] = useState(null)
  const [loadingKalori, setLoadingKalori] = useState(true)
  const [errorKalori, setErrorKalori] = useState(null)

  const [dailyPlan, setDailyPlan] = useState({ sarapan: [], makan_siang: [], makan_malam: [], camilan: [] })
  const [serverRecommendations, setServerRecommendations] = useState({ sarapan: null, makan_siang: null, makan_malam: null, camilan: null })
  const [loadingServerRec, setLoadingServerRec] = useState(false)
  const [serverError, setServerError] = useState(null)

  const [userId, setUserId] = useState(null)
  const [cookedFoods, setCookedFoods] = useState(null)
  const [combinedFoods, setCombinedFoods] = useState([])

  // recipe modal
  const [openRecipe, setOpenRecipe] = useState(null)

  useEffect(() => {
    const fetchSisaKalori = async () => {
      try {
        setLoadingKalori(true)
        const raw = typeof window !== 'undefined' ? localStorage.getItem('userData') ?? localStorage.getItem('user') : null
        if (!raw) {
          setErrorKalori('Data user tidak ditemukan di localStorage')
          setLoadingKalori(false)
          return
        }
        let parsed
        try { parsed = JSON.parse(raw) } catch (_) {
          setErrorKalori('Gagal membaca data user'); setLoadingKalori(false); return
        }
        const uid = parsed.id_user ?? parsed.id ?? parsed.userId ?? (parsed.user && parsed.user.id_user) ?? (parsed.user && parsed.user.id)
        const email = parsed.email ?? (parsed.user && parsed.user.email)
        if (!uid && !email) { setErrorKalori('User ID / Email tidak ditemukan'); setLoadingKalori(false); return }
        setUserId(uid)
        const query = uid ? `userId=${uid}` : `email=${encodeURIComponent(email)}`
        const res = await fetch(`/api/tracking/sisa-kalori?${query}`)
        const data = await res.json()
        if (!res.ok) throw new Error(data.message || 'Gagal mengambil data')
        const sisa = typeof data.sisaKalori !== 'undefined' ? data.sisaKalori : (typeof data.sisa !== 'undefined' ? data.sisa : 0)
        setSisaKalori(typeof sisa === 'number' ? sisa : Number(sisa || 0))
        setKaloriSummary(data)
      } catch (err) {
        console.error(err); setErrorKalori(err.message || String(err))
      } finally { setLoadingKalori(false) }
    }
    fetchSisaKalori()
  }, [])

  useEffect(() => {
    let mounted = true
    async function loadCooked() {
      try {
        const res = await fetch(COOKED_JSON_URL)
        if (!res.ok) throw new Error('Gagal memuat cooked foods')
        const data = await res.json()
        const arr = normalizeCookedArray(Array.isArray(data) ? data : data.foods || [])
        if (mounted) { setCookedFoods(arr); setCombinedFoods(arr) }
      } catch (err) {
        console.error('Error loading cooked JSON', err)
        if (mounted) { setCookedFoods([]); setCombinedFoods([]) }
      }
    }
    loadCooked()
    return () => { mounted = false }
  }, [])

  useEffect(() => {
    if (sisaKalori == null) return
    if (!Array.isArray(combinedFoods) || combinedFoods.length === 0) {
      setDailyPlan({ sarapan: [], makan_siang: [], makan_malam: [], camilan: [] }); return
    }
    const { byMeal, targets } = generateDailyPlan(sisaKalori, combinedFoods)
    setDailyPlan(byMeal)

    const calls = async () => {
      try {
        setLoadingServerRec(true); setServerError(null)
        const mapping = {
          sarapan: { apiMeal: 'breakfast', sisa: targets.targetSarapan },
          makan_siang: { apiMeal: 'lunch', sisa: targets.targetSiang },
          makan_malam: { apiMeal: 'dinner', sisa: targets.targetMalam },
          camilan: { apiMeal: 'snack', sisa: targets.targetCamilan }
        }
        const nextServerRecs = { ...serverRecommendations }
        for (const [key, info] of Object.entries(mapping)) {
          try {
            const payload = { userId, sisaKalori: info.sisa, meal: info.apiMeal }
            const res = await fetch('/api/recomendation', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(payload)
            })
            const data = await res.json()
            if (!res.ok) { nextServerRecs[key] = null }
            else {
              const serverList = data.rekomendasi || data.recommendations || data.result || data.items || data.data || (Array.isArray(data) ? data : null)
              nextServerRecs[key] = Array.isArray(serverList) ? serverList : null
            }
          } catch (err) { console.error('Error calling /api/recomendation for', key, err); nextServerRecs[key] = null }
        }
        setServerRecommendations(nextServerRecs)
      } catch (err) { console.error('Error in calls()', err); setServerError(err.message || String(err)) }
      finally { setLoadingServerRec(false) }
    }
    calls()
  }, [sisaKalori, combinedFoods])

  function getRenderedFoodsForKey(key) {
    const srv = serverRecommendations[key]
    if (srv && Array.isArray(srv) && srv.length > 0) {
      return srv.map((item, index) => {
        const localMatch = (combinedFoods || []).find((f) => {
          if (!f) return false
          const a = String((f.name ?? '')).toLowerCase().trim()
          const b = String(item.nama ?? item.name ?? '').toLowerCase().trim()
          return a === b || Number(f.id) === Number(item.label)
        })
        return {
          id: item.label ?? item.id ?? `${key}-${index}`,
          name: item.nama ?? item.name ?? (localMatch && localMatch.name) ?? `Makanan ${index + 1}`,
          kalori: item.kalori ?? item.calories ?? (localMatch && localMatch.kalori) ?? 0,
          protein: item.protein ?? item.protein_g ?? (localMatch && localMatch.protein) ?? 0,
          carbs: item.carbs ?? item.carbohydrate ?? item.carbohidrat ?? (localMatch && localMatch.carbs) ?? 0,
          fat: item.fat ?? item.lemak ?? (localMatch && localMatch.fat) ?? 0,
          tags: item.tags ?? (localMatch && localMatch.tags) ?? [],
          recipe: item.recipe ?? (localMatch && localMatch.recipe) ?? null
        }
      })
    }
    return (dailyPlan[key] || []).map((it, idx) => ({
      id: it.id ?? `${key}-fallback-${idx}`,
      name: it.name ?? it.nama ?? `Makanan ${idx + 1}`,
      kalori: it.kalori ?? 0,
      protein: it.protein ?? 0,
      carbs: it.carbs ?? 0,
      fat: it.fat ?? 0,
      tags: it.tags ?? [],
      recipe: it.recipe ?? null
    }))
  }

  function accentColorFor(key) { return accent[key] ?? brand.purple }

  /* Recipe modal: tidy formatting */
  function RecipeModal({ open, data, onClose }) {
    if (!open || !data) return null

    // normalize recipe object (flexible)
    const recipe = (data.recipe && typeof data.recipe === 'object') ? data.recipe : (typeof data.recipe === 'string' ? { description: data.recipe } : (data.recipe || {}))

    // build ingredients array
    const ingredients =
      recipe.ingredients && Array.isArray(recipe.ingredients)
        ? recipe.ingredients
        : recipe.bahan && Array.isArray(recipe.bahan)
        ? recipe.bahan
        : (recipe.ingredients && typeof recipe.ingredients === 'string')
        ? recipe.ingredients.split(/\r?\n|,|;/).map(s => s.trim()).filter(Boolean)
        : (recipe.bahan && typeof recipe.bahan === 'string')
        ? recipe.bahan.split(/\r?\n|,|;/).map(s => s.trim()).filter(Boolean)
        : []

    // build steps array
    const steps =
      recipe.steps && Array.isArray(recipe.steps)
        ? recipe.steps
        : recipe.langkah && Array.isArray(recipe.langkah)
        ? recipe.langkah
        : (recipe.steps && typeof recipe.steps === 'string')
        ? recipe.steps.split(/\r?\n/).map(s => s.trim()).filter(Boolean)
        : (recipe.langkah && typeof recipe.langkah === 'string')
        ? recipe.langkah.split(/\r?\n/).map(s => s.trim()).filter(Boolean)
        : []

    // macros: fallback to root item fields
    const macros = {
      kalori: Number(recipe.kalori ?? recipe.calories ?? data.kalori ?? data.calories ?? 0) || 0,
      protein: Number(recipe.protein ?? data.protein ?? 0) || 0,
      carbs: Number(recipe.carbs ?? recipe.carbohydrate ?? data.carbs ?? data.carbohydrate ?? 0) || 0,
      fat: Number(recipe.fat ?? data.fat ?? 0) || 0
    }

    return (
      <div style={{
        position: 'fixed', left: 0, top: 0, right: 0, bottom: 0,
        background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999
      }}>
        <div role="dialog" aria-modal="true" style={{ width: 'min(880px,96%)', maxHeight: '90vh', overflow: 'auto', background: '#fff', borderRadius: 12, padding: 22, boxShadow: '0 20px 60px rgba(2,6,23,0.25)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
            <div style={{ flex: 1 }}>
              <h3 style={{ margin: 0, fontSize: 20 }}>{data.name || recipe.title || 'Resep'}</h3>
              <div style={{ color: brand.muted, marginTop: 6, fontSize: 13 }}>
                Waktu: <strong>{recipe.cook_time_min ?? recipe.cook_time ?? recipe.time ?? '—'}</strong> • Porsi: <strong>{recipe.servings ?? recipe.porsi ?? 1}</strong>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <button onClick={onClose} aria-label="Tutup" style={{ border: 'none', background: '#fff', fontSize: 20, cursor: 'pointer', color: brand.muted }}>✕</button>
            </div>
          </div>

          {/* MACROS (clean pills) */}
          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <div style={{ padding: '8px 12px', borderRadius: 10, background: '#f1f7ff', minWidth: 90 }}>
              <div style={{ fontSize: 12, color: brand.muted }}>Kalori</div>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{fmt(Math.round(macros.kalori))} kcal</div>
            </div>
            <div style={{ padding: '8px 12px', borderRadius: 10, background: '#fff', border: '1px solid rgba(2,6,23,0.04)', minWidth: 90 }}>
              <div style={{ fontSize: 12, color: brand.muted }}>Protein</div>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{fmt(Math.round(macros.protein))} g</div>
            </div>
            <div style={{ padding: '8px 12px', borderRadius: 10, background: '#fff', border: '1px solid rgba(2,6,23,0.04)', minWidth: 90 }}>
              <div style={{ fontSize: 12, color: brand.muted }}>Karbo</div>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{fmt(Math.round(macros.carbs))} g</div>
            </div>
            <div style={{ padding: '8px 12px', borderRadius: 10, background: '#fff', border: '1px solid rgba(2,6,23,0.04)', minWidth: 90 }}>
              <div style={{ fontSize: 12, color: brand.muted }}>Lemak</div>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{fmt(Math.round(macros.fat))} g</div>
            </div>
          </div>

          {/* MAIN CONTENT: two columns */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginTop: 18 }}>
            <div>
              <h4 style={{ marginBottom: 8 }}>Bahan</h4>
              {ingredients.length === 0 ? (
                <div style={{ color: brand.muted }}>Daftar bahan tidak tersedia.</div>
              ) : (
                <ul style={{ marginTop: 8, lineHeight: 1.6 }}>
                  {ingredients.map((ing, i) => <li key={i}>{typeof ing === 'string' ? ing : (ing.amount ? `${ing.amount} ${ing.name}` : ing.name || ing)}</li>)}
                </ul>
              )}
            </div>

            <div>
              <h4 style={{ marginBottom: 8 }}>Langkah</h4>
              {steps.length === 0 ? (
                <div style={{ color: brand.muted }}>Instruksi tidak tersedia.</div>
              ) : (
                <ol style={{ marginTop: 8, lineHeight: 1.6 }}>
                  {steps.map((s, i) => <li key={i} style={{ marginBottom: 10 }}>{s}</li>)}
                </ol>
              )}
            </div>
          </div>

          {recipe.notes && <div style={{ marginTop: 12, color: '#475569' }}><strong>Catatan:</strong> {recipe.notes}</div>}

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 18 }}>
            <button onClick={() => { alert('Fungsi tambah ke tracking belum diimplementasikan.'); }} style={{ background: brand.purple, color: '#fff', border: 'none', padding: '10px 14px', borderRadius: 8, cursor: 'pointer' }}>Tambah ke Tracking</button>
            <button onClick={onClose} style={{ background: '#fff', border: '1px solid rgba(2,6,23,0.08)', padding: '10px 14px', borderRadius: 8, cursor: 'pointer' }}>Tutup</button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={C.page}>
      <div style={{ marginBottom: 18 }}>
        <h1 style={{ fontSize: 32, fontWeight: 900, margin: 0, color: '#0f172a' }}>Rekomendasi Makanan</h1>
        <div style={{ color: brand.muted, marginTop: 6 }}>Pilihan disusun berdasarkan sisa kalori harian & model rekomendasi</div>
      </div>

      <div style={C.hero}>
        <div style={C.heroRow}>
          <div>
            <div style={C.heroText}>Pilihan makanan berdasarkan sisa kalori harian & model rekomendasi</div>
            <div style={C.heroSub}>Catat makananmu setiap hari agar rekomendasi semakin personal.</div>
          </div>
          <div style={{ visibility: 'hidden' }} />
        </div>

        <div style={C.statsGrid}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ ...C.statCard, flex: 1 }}>
              <div style={C.statLabel}>Target Kalori</div>
              <div style={C.statValue}>{loadingKalori ? <Skeleton /> : `${fmt(Number(kaloriSummary?.targetKalori ?? kaloriSummary?.target_kalori ?? 0))} kcal`}</div>
            </div>
            <div style={{ ...C.statCard, flex: 1 }}>
              <div style={C.statLabel}>Kalori Dikonsumsi</div>
              <div style={C.statValue}>{loadingKalori ? <Skeleton /> : `${fmt(Number(kaloriSummary?.dikonsumsi ?? kaloriSummary?.kaloriDikonsumsi ?? kaloriSummary?.kalori_dikonsumsi ?? 0))} kcal`}</div>
            </div>
            <div style={{ ...C.statCard, flex: 1 }}>
              <div style={C.statLabel}>Kalori Dibakar</div>
              <div style={C.statValue}>{loadingKalori ? <Skeleton /> : `${fmt(Number(kaloriSummary?.dibakar ?? kaloriSummary?.kaloriDibakar ?? kaloriSummary?.kalori_dibakar ?? 0))} kcal`}</div>
            </div>
            <div style={{ ...C.statCard, flex: 1, background: '#ecfdf5' }}>
              <div style={{ fontSize: 12, color: '#16a34a' }}>Sisa Kalori Hari Ini</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: '#065f46', marginTop: 8 }}>{loadingKalori ? <Skeleton /> : `${fmt(Number(sisaKalori ?? 0))} kcal`}</div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 12, color: brand.muted, fontSize: 13 }}>
        {errorKalori ? `Error: ${errorKalori}` : serverError ? `Server: ${serverError}` : ''}
      </div>

      <div style={C.meals}>
        {['sarapan','makan_siang','makan_malam','camilan'].map((key) => {
          const foods = getRenderedFoodsForKey(key)
          const title = key === 'sarapan' ? 'Sarapan' : key === 'makan_siang' ? 'Makan Siang' : key === 'makan_malam' ? 'Makan Malam' : 'Camilan'
          return (
            <section key={key}>
              <div style={C.sectionHead}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: `${accentColorFor(key)}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18 }}>
                    {key === 'sarapan' ? '🍳' : key === 'makan_siang' ? '🍽️' : key === 'makan_malam' ? '🌙' : '🍪'}
                  </div>
                  <h2 style={C.sectionH2}>{title}</h2>
                </div>
                <div style={{ color: brand.muted, fontSize: 13 }}>{loadingServerRec ? 'Memuat...' : `${foods?.length ?? 0} pilihan`}</div>
              </div>

              {loadingServerRec ? (
                <div style={{ ...C.mealCard, borderLeft: `6px solid ${accentColorFor(key)}` }}>
                  <div style={C.left}>
                    <div style={{ width: 8, height: 36, borderRadius: 6, background: `${accentColorFor(key)}22` }} />
                    <div>
                      <div style={{ height: 14, width: 240, background: '#eef2ff', borderRadius: 6 }} />
                      <div style={{ height: 12, width: 120, background: '#f0f7ff', borderRadius: 6, marginTop: 8 }} />
                    </div>
                  </div>
                  <div style={C.right}><div style={{ height: 14, width: 60, background: '#eef2ff', borderRadius: 6 }} /></div>
                </div>
              ) : !foods || foods.length === 0 ? (
                <div style={C.statCard}>Belum ada rekomendasi untuk {title}. Catat makanan Anda agar rekomendasi menjadi lebih baik.</div>
              ) : (
                foods.map((food) => (
                  <div key={`${key}-${food.id}`} style={{ ...C.mealCard, borderLeft: `6px solid ${accentColorFor(key)}` }}>
                    <div style={C.left}>
                      <div style={{ width: 8, height: 36, borderRadius: 6, background: `${accentColorFor(key)}22` }} />
                      <div>
                        <div style={C.name}>{food.name}</div>
                        <div style={C.meta}>Protein: <strong>{Math.round(food.protein || 0)} g</strong> • Karbo: <strong>{Math.round(food.carbs || 0)} g</strong> • Lemak: <strong>{Math.round(food.fat || 0)} g</strong></div>
                        {Array.isArray(food.tags) && food.tags.length > 0 && (
                          <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                            {food.tags.slice(0, 3).map((t, i) => <div key={i} style={{ fontSize: 12, padding: '6px 9px', borderRadius: 999, background: '#fff', border: '1px solid rgba(15,23,42,0.04)' }}>{t}</div>)}
                          </div>
                        )}
                      </div>
                    </div>

                    <div style={C.right}>
                      <div style={{ fontWeight: 900, fontSize: 15 }}>{fmt(Math.round(food.kalori || 0))} kcal</div>
                      <div style={{ marginTop: 8 }}>
                        {food.recipe ? <button onClick={() => setOpenRecipe({ name: food.name, recipe: food.recipe, kalori: food.kalori, protein: food.protein, carbs: food.carbs, fat: food.fat })} style={{ padding: '8px 10px', borderRadius: 8, border: 'none', background: brand.purple, color: '#fff', cursor: 'pointer' }}>Lihat Resep</button> : <span style={{ color: brand.muted }}>Resep tidak tersedia</span>}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </section>
          )
        })}
      </div>

      <div style={{ marginTop: 18, textAlign: 'center', color: brand.muted, fontSize: 13 }}>
        Tips: Catat makanan yang Anda makan agar rekomendasi semakin akurat dan personal.
      </div>

      <RecipeModal open={!!openRecipe} data={openRecipe} onClose={() => setOpenRecipe(null)} />
    </div>
  )
}
