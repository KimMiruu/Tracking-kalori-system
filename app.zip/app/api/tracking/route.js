import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

// =============================
//   GET — Ambil tracking hari ini
// =============================
export async function GET (req) {
  try {
    const { searchParams } = new URL(req.url)
    const id_user = searchParams.get('id_user')
    const tanggal = searchParams.get('tanggal')

    if (!id_user || !tanggal) {
      return NextResponse.json(
        { error: 'id_user atau tanggal tidak valid' },
        { status: 400 }
      )
    }

    const [rows] = await db.query(
      `SELECT * FROM tb_tracking WHERE id_user = ? AND tanggal = ?`,
      [id_user, tanggal]
    )

    if (rows.length === 0) {
      return NextResponse.json({})
    }

    return NextResponse.json(rows[0])
  } catch (error) {
    console.error('GET /api/tracking error:', error)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

// =============================
//   POST — Simpan semua tracking
// =============================
export async function POST (req) {
  try {
    const body = await req.json()

    const {
      id_user,
      tanggal,
      kalori_dikonsumsi = 0,
      kalori_dibakar = 0,
      air = 0,
      protein = 0,
      karbohidrat = 0,
      lemak = 0,
      meals = [],
      exercises = []
    } = body

    if (!id_user || !tanggal) {
      return NextResponse.json(
        { error: 'id_user atau tanggal tidak valid' },
        { status: 400 }
      )
    }

    // Cek apakah data hari itu sudah ada
    const [existing] = await db.query(
      `SELECT * FROM tb_tracking WHERE id_user = ? AND tanggal = ?`,
      [id_user, tanggal]
    )

    if (existing.length > 0) {
      // Update data tracking
      await db.query(
        `UPDATE tb_tracking 
         SET 
           kalori_dikonsumsi = ?, 
           kalori_dibakar = ?, 
           air = ?,
           protein = ?,
           karbohidrat = ?,
           lemak = ?,
           detail_makanan = ?,
           detail_aktivitas = ?
         WHERE id_user = ? AND tanggal = ?`,
        [
          kalori_dikonsumsi,
          kalori_dibakar,
          air,
          protein,
          karbohidrat,
          lemak,
          JSON.stringify(meals),
          JSON.stringify(exercises),
          id_user,
          tanggal
        ]
      )

      return NextResponse.json({ message: 'Data tracking berhasil diupdate' })
    }

    // Otherwise → Insert baru
    await db.query(
      `INSERT INTO tb_tracking 
       (id_user, tanggal, kalori_dikonsumsi, kalori_dibakar, air, protein, karbohidrat, lemak, detail_makanan, detail_aktivitas)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id_user,
        tanggal,
        kalori_dikonsumsi,
        kalori_dibakar,
        air,
        protein,
        karbohidrat,
        lemak,
        JSON.stringify(meals),
        JSON.stringify(exercises)
      ]
    )

    return NextResponse.json({ message: 'Tracking baru disimpan' })
  } catch (error) {
    console.error('POST /api/tracking error:', error)
    return NextResponse.json(
      { error: 'Gagal menyimpan tracking' },
      { status: 500 }
    )
  }
}
