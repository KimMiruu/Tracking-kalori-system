// app/app/api/recomendation/route.js
import { NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";
import mysql from "mysql2/promise";

// DB POOL
const pool = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASS || "",
    database: process.env.DB_NAME || "simplefit",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// UTILS
function toNumberSafe(v) {
    return Number(v || 0);
}

async function safeReadJson() {
    try {
        const parts = Array.prototype.slice.call(arguments);
        const fp = path.join.apply(path, [process.cwd()].concat(parts));
        const raw = await fs.readFile(fp, "utf-8");
        return JSON.parse(raw);
    } catch (err) {
        return null;
    }
}

// DB HELPERS
async function getConsumedToday(userId) {
    if (!userId) return 0;
    const conn = await pool.getConnection();
    try {
        const [rows] = await conn.query(
            "SELECT COALESCE(SUM(kalori_dikonsumsi),0) AS total FROM tb_tracking WHERE id_user = ? AND tanggal = CURDATE()", [userId]
        );
        if (rows && rows[0] && typeof rows[0].total !== "undefined") {
            return toNumberSafe(rows[0].total);
        }
        return 0;
    } finally {
        conn.release();
    }
}

async function getBurnedToday(userId) {
    if (!userId) return 0;
    const conn = await pool.getConnection();
    try {
        const [rows] = await conn.query(
            "SELECT COALESCE(SUM(kalori_dibakar),0) AS total FROM tb_tracking WHERE id_user = ? AND tanggal = CURDATE()", [userId]
        );
        if (rows && rows[0] && typeof rows[0].total !== "undefined") {
            return toNumberSafe(rows[0].total);
        }
        return 0;
    } finally {
        conn.release();
    }
}

async function getUserTargetKalori(userId) {
    if (!userId) return null;
    const conn = await pool.getConnection();
    try {
        const [rows] = await conn.query(
            "SELECT target_kalori FROM tb_user_profile WHERE id_user = ? LIMIT 1", [userId]
        );
        if (rows && rows[0] && typeof rows[0].target_kalori !== "undefined") {
            return Number(rows[0].target_kalori);
        }
        return null;
    } finally {
        conn.release();
    }
}

// SCORE
function computeScore(item, sisaKalori, recentSet, proteinTarget) {
    const cal = toNumberSafe(item.kalori || item.calories);
    const protein = toNumberSafe(item.protein);
    const diff = Math.abs(sisaKalori - cal);

    const calScore = sisaKalori > 0 ? Math.max(0, 1 - diff / (sisaKalori * 0.7 + 1)) : 0;
    const protScore = Math.min(1, protein / 100);
    const protFactor = proteinTarget ? Math.min(1, protein / (proteinTarget * 0.5)) : protScore;

    const idVal = Number(item.id_makanan || item.id || 0);
    const recentPenalty = recentSet.has(idVal) ? 0.4 : 1.0;

    return 0.75 * calScore + 0.20 * protFactor * recentPenalty + 0.05;
}

// KNAPSACK SELECTOR
function knapSelect(items, target, maxItems = 4, margin = 200) {
    const n = items.length;
    if (n === 0) return { chosen: [], totalCalories: 0 };

    var working = items.slice();
    if (working.length > 200) {
        working = working.slice().sort(function(a, b) {
            return (b._score || 0) - (a._score || 0);
        }).slice(0, 200);
    }
    if (working.length > 30) {
        working = working.slice(0, 30);
    }

    var K = maxItems;
    var DP = Array.apply(null, Array(K + 1)).map(function() { return new Map(); });
    DP[0].set(0, { score: 0, mask: 0 });

    for (var i = 0; i < working.length; i++) {
        var cal = Math.round(toNumberSafe(working[i].kalori || working[i].calories));
        var sc = toNumberSafe(working[i]._score);
        for (var k = K - 1; k >= 0; k--) {
            var entries = Array.from(DP[k].entries());
            for (var ei = 0; ei < entries.length; ei++) {
                var c = entries[ei][0];
                var val = entries[ei][1];
                var nc = c + cal;
                if (nc > target + margin) continue;
                var newScore = val.score + sc;
                var prev = DP[k + 1].get(nc);
                if (!prev || newScore > prev.score) {
                    DP[k + 1].set(nc, { score: newScore, mask: val.mask | (1 << i) });
                }
            }
        }
    }

    var best = null;
    for (var kk = 1; kk <= K; kk++) {
        var entriesK = Array.from(DP[kk].entries());
        for (var eji = 0; eji < entriesK.length; eji++) {
            var c2 = entriesK[eji][0];
            var v2 = entriesK[eji][1];
            var diff = Math.abs(target - c2);
            if (!best || diff < best.diff || (diff === best.diff && v2.score > best.score)) {
                best = { diff: diff, score: v2.score, total: c2, mask: v2.mask };
            }
        }
    }

    if (!best) return { chosen: [], totalCalories: 0 };

    var chosen = [];
    for (var ii = 0; ii < working.length; ii++) {
        if (best.mask & (1 << ii)) chosen.push(working[ii]);
    }

    return { chosen: chosen, totalCalories: best.total };
}

// MAIN HANDLER
export async function POST(req) {
    try {
        var body = await req.json();
        var userId = body.userId || null;
        var recentFoodIds = Array.isArray(body.recentFoodIds) ? body.recentFoodIds : [];
        var proteinTarget = body.userProteinTarget || null;
        var recentSet = new Set((recentFoodIds || []).map(function(x) { return Number(x); }));

        // load foods (prefer file with recipes; fallback to cooked only)
        var cooked = await safeReadJson("app", "data", "food_recommendations_with_recipes.json");
        if (!cooked) {
            cooked = await safeReadJson("app", "data", "food_recommendations_cooked_only.json");
        }

        var foods = [];
        if (Array.isArray(cooked)) {
            foods = cooked;
        } else if (cooked && Array.isArray(cooked.foods)) {
            foods = cooked.foods;
        } else if (cooked && typeof cooked === "object") {
            foods = Object.keys(cooked).map(function(k) { return cooked[k]; });
        } else {
            foods = [];
        }

        // compute sisaKalori
        var sisaKalori = toNumberSafe(body.sisaKalori || 0);
        if (userId) {
            var target = await getUserTargetKalori(userId);
            var consumed = await getConsumedToday(userId);
            var burned = await getBurnedToday(userId);
            sisaKalori = Math.max(0, (target || 0) - consumed + burned);
        }

        // prefilter
        var margin = 200;
        var candidates = foods.filter(function(f) {
            var cal = toNumberSafe(f.kalori || f.calories);
            return cal > 0 && cal <= sisaKalori + margin;
        });

        if (candidates.length > 2000) {
            candidates = candidates
                .map(function(f) { return { f: f, diff: Math.abs(toNumberSafe(f.kalori || f.calories) - sisaKalori) }; })
                .sort(function(a, b) { return a.diff - b.diff; })
                .slice(0, 800)
                .map(function(x) { return x.f; });
        }

        // scoring
        var scored = candidates.map(function(f) {
            var copy = Object.assign({}, f);
            copy._score = computeScore(copy, sisaKalori, recentSet, proteinTarget);
            return copy;
        });

        // deterministic sort: score desc, id asc
        scored.sort(function(a, b) {
            var sa = toNumberSafe(a._score);
            var sb = toNumberSafe(b._score);
            if (sb !== sa) return sb - sa;
            var ida = Number(a.id_makanan || a.id || 0);
            var idb = Number(b.id_makanan || b.id || 0);
            return ida - idb;
        });

        // knapsack
        var knap = knapSelect(scored, sisaKalori, 4, margin);
        var alternatif = (knap && knap.chosen && knap.chosen.length > 0) ? knap.chosen : scored.slice(0, Math.min(4, scored.length));

        // finalize (include recipe if present)
        var result = [];
        var added = new Set();
        for (var i = 0; i < alternatif.length; i++) {
            var it = alternatif[i];
            var idVal = Number(it.id_makanan || it.id || 0);
            if (!added.has(idVal)) {
                var out = Object.assign({}, it);
                if (it.recipe) out.recipe = it.recipe;
                result.push(out);
                added.add(idVal);
            }
        }

        var totalCalories = 0;
        for (var j = 0; j < result.length; j++) {
            totalCalories += toNumberSafe(result[j].kalori || result[j].calories || 0);
        }

        return NextResponse.json({
            recommendations: result,
            sisaKaloriFromServer: sisaKalori,
            totalCalories: totalCalories
        });
    } catch (err) {
        console.error("REKOM ERROR:", err && (err.stack || err.toString ? err.toString() : err));
        return NextResponse.json({ error: String(err) }, { status: 500 });
    }
}